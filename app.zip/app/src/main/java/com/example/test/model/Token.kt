package com.example.test.model

data class Token(
    val token: String?,
)