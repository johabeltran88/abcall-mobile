package com.example.test.model

data class Consumer(
    val email: String?,
    val password: String?,
)